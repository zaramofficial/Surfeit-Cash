import 'package:cash_rocket/Screen/Constant%20Data/constant.dart';
import 'package:flutter/material.dart';

String splashLogo = 'images/update/splash.png';
String onBoard1 = 'images/update/onboard1.png';
String onBoard2 = 'images/update/onboard2.png';
String onBoard3 = 'images/update/onboard3.png';
String logo = 'images/update/logo.png';
String appsName = 'Cash Rocket';
String backgroundImage = 'images/update/bg.png';
String welcomeBg = 'images/update/welcomeBg.png';
String svgContainer = 'images/shape.svg';
Color kLightTextColor = kWhite.withOpacity(0.7);
