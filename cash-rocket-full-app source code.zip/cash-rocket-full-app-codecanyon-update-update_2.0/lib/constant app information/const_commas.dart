import 'package:intl/intl.dart';

NumberFormat myFormat = NumberFormat.decimalPattern('en_us');
